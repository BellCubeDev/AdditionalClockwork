# Teanslations Folder

I made this folder quite easy to extract. Simply choose your perspective and move the contents to `data\Strings`!
