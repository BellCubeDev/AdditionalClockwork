# Marked Shadows

Adds Shadowmarks to various important locations in Clockwork once you complete the Clockwork questline and are a guild member.

* Travel Room - Adds one Shadowmark just beside the stairs leading up to the Main Hall
* Castle Exterior - Adds one Shadowmark right beside your fromt door, in-line with the rest of Skyrim
* Termini - Adds a Shadowmark beside the entrance to each Clockwork Castle Terminus's transport device.

## Merged Module

I merged them for you because I'm nice. I recommend all of them anyway, the Shadowmarks are fun to forget about and notice a month later. "Oh, yeah! I remember those now!"
