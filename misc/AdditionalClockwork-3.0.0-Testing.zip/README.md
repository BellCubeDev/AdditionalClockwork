# Additional Clockwork FOMOD

This is the FOMOD installer for Clockwork. [This filder](dist/) is actually zipped on a local clone of [the repo](https://github.com/BellCubeDev/AdditionalClockwork) whenever I release a new version.

# What is this mod?

Additional Clockwork is a [Skyrim: Special Edition](https://store.steampowered.com/app/489830) mod made by [BellCube Dev](https://github.com/BellCubeDev), a lover of [Clockwork](https://www.nexusmods.com/skyrimspecialedition/mods/4155) who wanted to see [better sorting](https://github.com/BellCubeDev/AdditionalClockwork/projects/10) that included modded items. As I worked, I got ideas, and eventually created an entire suit with plenty of ideas to come. Included in this suite are bug fixes, inter-mod patches, and entirely new content for Clockwork.
